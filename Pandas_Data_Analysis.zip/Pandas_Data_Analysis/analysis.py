import pandas as pd
import matplotlib.pyplot as plt

# Load CSV File
df = pd.read_csv("Employees.csv", skipinitialspace=True)

# Convert Salary to Number
df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")

# Remove Extra Spaces
df["City"] = df["City"].str.strip()
df["Name"] = df["Name"].str.strip()
df["Department"] = df["Department"].str.strip()

print("\n===== First 5 Rows =====\n")
print(df.head())

print("\n===== Dataset Information =====\n")
df.info()

print("\n===== Missing Values =====\n")
print(df.isnull().sum())

# Remove Missing Values
df = df.dropna()

# Remove Duplicate Rows
df = df.drop_duplicates()

print("\n===== Clean Data =====\n")
print(df)

print("\n===== Delhi Employees =====\n")
print(df[df["City"] == "Delhi"])

print("\n===== Employees with Salary Greater Than 30000 =====\n")
print(df[df["Salary"] > 30000])

print("\n===== Average Salary by City =====\n")
print(df.groupby("City")["Salary"].mean())

print("\n===== Average Salary =====\n")
print(df["Salary"].mean())

print("\n===== Highest Salary =====\n")
print(df["Salary"].max())

print("\n===== Lowest Salary =====\n")
print(df["Salary"].min())

print("\n===== Summary Statistics =====\n")
print(df.describe())

# Graph
df.groupby("City")["Salary"].mean().plot(
    kind="bar",
    color=["red", "blue", "green"]
)

plt.title("Average Salary by City")
plt.xlabel("City")
plt.ylabel("Average Salary")
plt.show()